#!/bin/bash
# Running Python program

python3 final.py $1 $2
