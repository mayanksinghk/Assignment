open A1
exception Not_implemented

(* hastype : ((string * exptype) list) -> exptree -> exptype -> bool *)
let rec hastype g e t = raise Not_implemented

(* yields : ((string * exptree) list) -> definition -> ((string * exptree) list) -> bool *)
let rec yields g d g_dash = raise Not_implemented
